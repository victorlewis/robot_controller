#include <iostream>
#include <hash_set.h>
#include <set>
#include <vector>
#include <fstream.h>
#include <stdlib.h>
#include <math.h>

#include <memory.h>
//#include <malloc.h>
#include <ctype.h>
#include <string.h>
#include <string>
#include <strings.h>
//#include <sys/types.h>


#include "s_hull_pro.h"

/* copyright 2010 Dr David Sinclair
   david@s-hull.org
 
   program to compute Delaunay triangulation of a set of points.
 
   this code is released under GPL2, 
   a copy ofthe license can be found at
   http://www.gnu.org/licenses/gpl-2.0.html

   you can purchase a un-restricted licnese from 
   http://www.s-hull.org 
   for the price of one beer!

   
*/


#include <sys/time.h>

int main(int argc, char *argv[])
{
  if( argc == 1 ){
    cerr << "s_hull_pro delaunay triangulation demo" << endl;
    cerr << "usage: _>   shullpro_integer <points_file> <triangles_file> " << endl;
    
    float goat =  ( 2147483648.0-1) /1000.0;
    
    std::vector<Shx_int> pts;
    Shx_int pt;
    srandom(1);
    
    //    for(int v=0; v<200; v++){
      //for(int v=0; v<20000; v++){
      //
for(int v=0; v<100000; v++){
      pt.id = v;
      pt.r = ((float) random())/goat - 50;
      pt.c = ((float) random())/goat - 50;
      
      pts.push_back(pt);
    }
    
    write_Shx(pts, "pts.mat");
    cerr << pts.size() << " randomly generated points written to pts.mat" << endl;
    
    std::vector<Triad_int> triads;
    
    struct timeval tv1, tv2;    gettimeofday(&tv1, NULL);
    
    
    s_hull_pro_integer( pts, triads);
    
    
     gettimeofday(&tv2, NULL);
    float tx =  (tv2.tv_sec + tv2.tv_usec / 1000000.0) - ( tv1.tv_sec + tv1.tv_usec / 1000000.0);
    
    cerr <<  tx << " seconds for triangulation" << endl;
    
    
    write_Triads(triads, "triangles.mat");
    cerr << "triangles written to triangles.mat" << endl;
    
    
    exit(0);
  }
  else if( argc > 1){
    
    cerr << "reading points from " << argv[1] << endl;
    std::vector<Shx_int> pts2;
    
    int nump = read_Shx(pts2, argv[1]);
    cerr << nump << "points read" << endl;
    
    
    //    struct timeval tv1, tv2;    gettimeofday(&tv1, NULL);
    
    std::vector<Triad_int> triads;
    s_hull_pro_integer( pts2, triads);
    
    
    //    gettimeofday(&tv2, NULL);
    //float tx =  (tv2.tv_sec + tv2.tv_usec / 1000000.0) - ( tv1.tv_sec + tv1.tv_usec / 1000000.0);
    
    //    cerr <<  tx << " seconds for triangulation" << endl;
    
    
    if( argc == 2 ){
      write_Triads(triads, "triangles.mat");
      cerr << "triangles written to triangles.mat" << endl;
    }
    else{
      write_Triads(triads, argv[2]);
      cerr << "triangles written to " << argv[2] << endl;
    }
  }
  
  exit(0);
}

