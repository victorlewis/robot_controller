#include <iostream>
#include <set>
#include <vector>
#include <fstream>
#include <stdlib.h>
#include <math.h>
#include <string>
#include <algorithm>


#include "s_hull_pro.h"

using namespace std;


/* copyright 2012 Dr David Sinclair
   david@s-hull.org
 
   program to compute Delaunay triangulation of a set of points.
  
   this code is released under GPL2, 
   a copy ofthe license can be found at
   http://www.gnu.org/licenses/gpl-2.0.html

   you can purchase a un-restricted licnese from 
   http://www.s-hull.org 
   for the price of one beer!
   
 */



/*  
    read an ascii file of (r,c) point pairs.

    the first line of the points file should contain
    "NUMP  2 points"

    if it does not have the word points in it the first line is 
    interpretted as a point pair.

 */

int read_Shx(std::vector<Shx_int> &pts, char * fname){
  char s0[513];
  int nump =0;
  float p1,p2;

  Shx_int pt;

  std::string line;
  std::string points_str("points");

  std::ifstream myfile;
  myfile.open(fname);

  if (myfile.is_open()){
    
    getline (myfile,line);
	//int numc = line.length();

    // check string for the string "points"
    int n = (int) line.find( points_str);
	if( n > 0){ 
      while ( myfile.good() ){
	getline (myfile,line);
	if( line.length() <= 512){
	  copy( line.begin(), line.end(), s0);
	  s0[line.length()] = 0;
	  int v = sscanf( s0, "%g %g", &p1,&p2);
	  if( v>0 ){
	    pt.id = nump; 
	    nump++;
	    pt.r = (int)p1;
	    pt.c = (int)p2;
	    pts.push_back(pt);
	  }
	}   
      }
    }
    else{   // assume all number pairs on a line are points
      if( line.length() <= 512){
	copy( line.begin(), line.end(), s0);
	s0[line.length()] = 0;
	int v = sscanf( s0, "%g %g", &p1,&p2);
	if( v>0 ){
	    pt.id = nump; 
	    nump++;
	    pt.r = (int)p1;
	    pt.c = (int)p2;
	  pts.push_back(pt);
	}
      }   

      while ( myfile.good() ){
	getline (myfile,line);
	if( line.length() <= 512){
	  copy( line.begin(), line.end(), s0);
	  s0[line.length()] = 0;
	  int v = sscanf( s0, "%g %g", &p1,&p2);
	  if( v>0 ){
	    pt.id = nump; 
	    nump++;
	    pt.r = (int)p1;
	    pt.c = (int)p2;
	    pts.push_back(pt);
	  }
	}   
      }
    }
    myfile.close();
  }

  nump = (int) pts.size();

  return(nump);
};

/*
	write out a set of points to disk


*/

void write_Shx(std::vector<Shx_int> &pts, char * fname){
   std::ofstream out(fname, ios::out);
   
   int nr = (int) pts.size();
   out << nr << " 2 points" << endl;
   
   for (int r = 0; r < nr; r++){
     out << pts[r].r << ' ' << pts[r].c <<  endl;
   }
   out.close();
   
   return;
};



/*
 write out triangle ids to be compatible with matlab/octave array numbering.

 */
void write_Triads(std::vector<Triad_int> &ts, char * fname){
   std::ofstream out(fname, ios::out);
   
   int nr = (int) ts.size();
   out << nr << " 6   point-ids (1,2,3)  adjacent triangle-ids ( limbs ab  ac  bc )" << endl;
   
   for (int r = 0; r < nr; r++){
     out << ts[r].a+1 << ' ' << ts[r].b+1 <<' ' << ts[r].c+1 <<' ' 
	 << ts[r].ab+1 <<' ' << ts[r].ac+1 <<' ' << ts[r].bc+1 << endl; 
   }
   out.close();
   
   return;
};





/* find the opening hull for sweep-line triangualtion.

   includes duplicate point test.

 */

int init_hull_int( std::vector<Shx_int> &pts, std::vector<Shx_int> &hull, 
		   std::vector<Triad_int> &triads)
{
  int nump = pts.size();
  std::vector<int> outx;

  if( nump < 3 ){
    return(-1);
  }

  sort(pts.begin(), pts.end());
  
  for( int k=0; k<nump-1; k++){
    if( pts[k].r == pts[k+1].r && pts[k].c == pts[k+1].c ){
      // cerr << "duplicate-point " << pts[k+1].id << "   " << pts[pts[k+1].id].r 
      //   << " " << pts[pts[k+1].id].c << endl;

      pts.erase(pts.begin()+k);
      nump--;
      k--;
    }
  }

  cerr << "duplicate filterd points " << pts.size() << endl;


  // find minimum opening trianglulated hull.
  int numh = 2;
  int flag = 1;
  hull.push_back( pts[0]);
  hull.push_back( pts[1]);

  hull[0].tr = hull[1].r-hull[0].r;
  hull[0].tc = hull[1].c-hull[0].c;

  while( flag > 0 && numh < nump ){
    hull.push_back( pts[numh]);
    int tr = hull[numh].r-hull[numh-1].r;
    int tc = hull[numh].c-hull[numh-1].c;

    hull[numh-1].tr = tr;    
    hull[numh-1].tc = tc;    

    int dp =  -tr *  hull[0].tc +  tc *  hull[0].tr;
    if( dp != 0 ){
      flag = 0;
      if( dp > 0){ // right hand turn. reverse order of hull.
	// make the opening hull.

	int mid = numh/2;
	for( int h=0; h<=mid; h++){
	  Shx_int tmp = hull[h];
	  hull[h] = hull[numh-h];
	  hull[numh-h] = tmp;
	}

	hull[numh].tr = hull[0].r - hull[numh].r;
	hull[numh].tc = hull[0].c - hull[numh].c;


	for( int h=0; h<numh; h++){
	  hull[h].tr = hull[h+1].r - hull[h].r;
	  hull[h].tc = hull[h+1].c - hull[h].c;
	}



	// and fill in the triangles.
	if( numh >2 ){
	  for( int p=0; p<numh-1; p++){
	    Triad_int tri(hull[p].id, hull[p+1].id, hull[numh].id);
	    hull[p].trid = p;
	    tri.ab = -1;
	    tri.ac = -1;
	    tri.bc = -1;
	    triads.push_back(tri);
	    if( p > 0 ){
	      triads[p-1].bc = p;
	      triads[p].ac = p-1;
	    }
	  }

	  hull[numh-1].trid = numh-2;
	  hull[numh].trid = 0;
	  
	}
	else{ // only one starting triangle.
	  Triad_int tri(hull[0].id, hull[1].id, hull[2].id);
	  hull[0].trid = 0;
	  hull[1].trid = 0;
	  hull[2].trid = 0;
	  tri.ab = -1;
	  tri.ac = -1;
	  tri.bc = -1;

	  triads.push_back(tri);
	}
      }
      else{  // left hand turn.
		// make the opening hull.
	hull[numh].tr = hull[0].r - hull[numh].r;
	hull[numh].tc = hull[0].c - hull[numh].c;

	// and fill in the triangles.
	if( numh >2 ){
	  for( int p=0; p<numh-1; p++){
	    Triad_int tri(hull[p].id, hull[p+1].id, hull[numh].id);
	    hull[p].trid = p;
	    tri.ab = -1;
	    tri.ac = -1;
	    tri.bc = -1;
	    triads.push_back(tri);
	    if( p > 0 ){
	      triads[p-1].bc = p;
	      triads[p].ac = p-1;
	    }
	  }

	  hull[numh-1].trid = numh-2;
	  hull[numh].trid = 0;
	  
	}
	else{ // only one starting triangle.
	  Triad_int tri(hull[0].id, hull[1].id, hull[2].id);
	  hull[0].trid = 0;
	  hull[1].trid = 0;
	  hull[2].trid = 0;
	  tri.ab = -1;
	  tri.ac = -1;
	  tri.bc = -1;

	  triads.push_back(tri);
	}
      }
    }
    numh++;
  }

  if( flag == 1 ){
    cerr << "linear set of points" << endl;
    return(-2); // liner set of points.
  }


  return(numh);
}






/*  the ids of the triangles associated with the 
    sides of the hull are tracked.
    
*/

int s_hull_pro_integer( std::vector<Shx_int> &pts, std::vector<Triad_int> &triads)
{

  int nump = (int) pts.size();


  if( nump < 3 ){
    cerr << "less than 3 points, aborting " << endl;
    return(-1);
  }
  std::vector<Shx_int> hull;


  int Kstart = init_hull_int( pts, hull, triads);
 
  //  write_Triads(triads, "tris0.mat");

  nump = pts.size(); // note duplicates removed.
  std::vector<int> slump;
  slump.resize(nump);

  for( int k=0; k<nump; k++){
    if( pts[k].id < nump){
      slump[ pts[k].id] = k;
    }
    else{
      int mx = pts[k].id+1;
      while( (int) slump.size() <= mx){
	slump.push_back(0);
      }
      slump[pts[k].id] = k;
    }
  }



  


  // add new points into hull (removing obscured ones from the chain)
  // and creating triangles....
  // that will need to be flipped.

  int dr, dc, rx,cx;
  Shx_int  ptx;
  int numt;

  for( int k=Kstart; k<nump; k++){
    rx = pts[k].r;    cx = pts[k].c;
    ptx.r = rx;
    ptx.c = cx;
    ptx.id = pts[k].id;

    int numh = (int) hull.size(), numh_old = numh;
    dr = rx- hull[0].r;    dc = cx- hull[0].c;  // outwards pointing from hull[0] to pt.

    std::vector<int> pidx, tridx;
    int hidx;  // new hull point location within hull.....


    int df = -dc* hull[0].tr + dr*hull[0].tc;    // visibility test vector.
    if( df < 0 ){  // starting with a visible hull facet !!!
      int e1 = 1, e2 = numh;
      hidx = 0;

      // check to see if segment numh is also visible
      df = -dc* hull[numh-1].tr + dr*hull[numh-1].tc;
      //cerr << df << ' ' ;
      if( df < 0 ){    // visible.
	pidx.push_back(hull[numh-1].id);
	tridx.push_back(hull[numh-1].trid);
	

	for( int h=0; h<numh-1; h++){
	  // if segment h is visible delete h
	  dr = rx- hull[h].r;    dc = cx- hull[h].c;
	  df = -dc* hull[h].tr + dr*hull[h].tc;
	  pidx.push_back(hull[h].id);
	  tridx.push_back(hull[h].trid);
	  if( df < 0 ){ 
	    hull.erase(hull.begin() + h);
	    h--;
	    numh--;
	  }
	  else{	  // quit on invisibility
	    ptx.tr = hull[h].r - ptx.r;
	    ptx.tc = hull[h].c - ptx.c;

	    hull.insert( hull.begin() , ptx);
	    numh++;
	    break;
	  }
	}
	// look backwards through the hull structure.
	
	for( int h=numh-2; h>0; h--){
	  // if segment h is visible delete h + 1
	  dr = rx- hull[h].r;    dc = cx- hull[h].c;
	  df = -dc* hull[h].tr + dr*hull[h].tc;

	  if( df < 0 ){  // h is visible 
	    pidx.insert(pidx.begin(), hull[h].id);
	    tridx.insert(tridx.begin(), hull[h].trid);
	    hull.erase(hull.begin() + h+1);  // erase end of chain
	    
	  }
	  else{

	    h = (int) hull.size()-1;
	    hull[h].tr = -hull[h].r + ptx.r;   // points at start of chain.
	    hull[h].tc = -hull[h].c + ptx.c;
	    break;
	  }
	}

	df = 9;

      }
      else{
	//	cerr << df << ' ' << endl;
	hidx = 1;  // keep pt hull[0]
	tridx.push_back(hull[0].trid);
	pidx.push_back(hull[0].id);

	for( int h=1; h<numh; h++){
	  // if segment h is visible delete h  
	  dr = rx- hull[h].r;    dc = cx- hull[h].c;
	  df = -dc* hull[h].tr + dr*hull[h].tc;
	  pidx.push_back(hull[h].id);
	  tridx.push_back(hull[h].trid);
	  if( df < 0 ){                     // visible
	    hull.erase(hull.begin() + h);
	    h--;
	    numh--;
	  }
	  else{	  // quit on invisibility
	    ptx.tr = hull[h].r - ptx.r;
	    ptx.tc = hull[h].c - ptx.c;

	    hull[h-1].tr = ptx.r - hull[h-1].r;
	    hull[h-1].tc = ptx.c - hull[h-1].c;

	    hull.insert( hull.begin()+h, ptx);
	    break;
	  }
	}
      }

      df = 8;

    }
    else{
      int e1 = -1,  e2 = numh;
      for( int h=1; h<numh; h++){	
	dr = rx- hull[h].r;    dc = cx- hull[h].c;
	df = -dc* hull[h].tr + dr*hull[h].tc;
	if( df < 0 ){
	  if( e1 < 0 ) e1 = h;  // fist visible
	}
	else{
	  if( e1 > 0 ){ // first invisible segment.
	    e2 = h;
	    break;
	  }
	}

      }


      // triangle pidx starts at e1 and ends at e2 (inclusive).	
      if( e2 < numh ){
	for( int e=e1; e<=e2; e++){
	  pidx.push_back(hull[e].id);
	  tridx.push_back(hull[e].trid);
	}
      }
      else{
	for( int e=e1; e<e2; e++){
	  pidx.push_back(hull[e].id);
	  tridx.push_back(hull[e].trid);   // there are only n-1 triangles from n hull pts.
	}
	pidx.push_back(hull[0].id);
      }


      // erase elements e1+1 : e2-1 inclusive.
      
      if( e1 < e2-1){
	hull.erase(hull.begin() + e1+1, hull.begin()+ e2); 
      }

      // insert ptx at location e1+1.
      if( e2 == numh){
	ptx.tr = hull[0].r - ptx.r;
	ptx.tc = hull[0].c - ptx.c;
      }
      else{
	ptx.tr = hull[e1+1].r - ptx.r;
	ptx.tc = hull[e1+1].c - ptx.c;
      }

      hull[e1].tr = ptx.r - hull[e1].r;
      hull[e1].tc = ptx.c - hull[e1].c;
      
      hull.insert( hull.begin()+e1+1, ptx);
      hidx = e1+1;
      
    }


    int a = ptx.id, T0;
    Triad_int trx( a, 0,0);

    int npx = (int) pidx.size()-1;
    numt = (int) triads.size();
    T0 = numt;

    if( npx == 1){
       trx.b = pidx[0];
       trx.c = pidx[1];
      
      trx.bc = tridx[0];
      trx.ab = -1;
      trx.ac = -1;

      // index back into the triads.
      Triad_int &txx = triads[tridx[0]];
      if( ( trx.b == txx.a && trx.c == txx.b) |( trx.b == txx.b && trx.c == txx.a)) {
	txx.ab = numt;
      }
      else if( ( trx.b == txx.a && trx.c == txx.c) |( trx.b == txx.c && trx.c == txx.a)) {
	txx.ac = numt;
      }
      else if( ( trx.b == txx.b && trx.c == txx.c) |( trx.b == txx.c && trx.c == txx.b)) {
	txx.bc = numt;
      }
      

      hull[hidx].trid = numt;
      if( hidx > 0 )
	hull[hidx-1].trid = numt;
      else{
	numh = (int) hull.size();
	hull[numh-1].trid = numt;
      }
      triads.push_back( trx );
      numt++;
    }
    
    else{
      trx.ab = -1;
      for(int p=0; p<npx; p++){
	trx.b = pidx[p];
	trx.c = pidx[p+1];
  
    
	trx.bc = tridx[p];
	if( p > 0 )
	  trx.ab = numt-1;
	trx.ac = numt+1;
	
	// index back into the triads.
	Triad_int &txx = triads[tridx[p]];
	if( ( trx.b == txx.a && trx.c == txx.b) |( trx.b == txx.b && trx.c == txx.a)) {
	  txx.ab = numt;
	}
	else if( ( trx.b == txx.a && trx.c == txx.c) |( trx.b == txx.c && trx.c == txx.a)) {
	  txx.ac = numt;
	}
	else if( ( trx.b == txx.b && trx.c == txx.c) |( trx.b == txx.c && trx.c == txx.b)) {
	  txx.bc = numt;
	}
      
	triads.push_back( trx );
	numt++;
      }
      triads[numt-1].ac=-1;

      hull[hidx].trid = numt-1;
      if( hidx > 0 )
	hull[hidx-1].trid = T0;
      else{
	numh = (int) hull.size();
	hull[numh-1].trid = T0;
      }


    }

    //    write_Triads(triads, "tris1.mat");
    int dfog = 8;

  }

  cerr << "of triangles " << triads.size() << " to be flipped. "<< endl;
 
  //   write_Triads(triads, "tris2.mat");

  std::set<int> ids, ids2;

  int tf = T_flip_pro( pts, triads, slump, numt, 0, ids);
  if( tf < 0 ){
    cerr << "cannot triangualte this set " << endl;

    return(-3);
  }

  //  write_Triads(triads, "tris1.mat");

  int nits = (int) ids.size(), nit=1;
  while(  nits > 0 && nit < 100){

    tf = T_flip_pro_idx( pts, triads, slump, ids);
    nits = (int) ids.size();
    //    cerr << "flipping cycle  " << nit << "   active triangles " << nits << endl;

    //char tname[128];
    //sprintf(tname,"tris%d.mat",nit);
    //write_Triads(triads, tname);

    nit ++;
    if( tf < 0 ){
      cerr << "cannot triangualte this set " << endl;

      return(-4);
    } 
  }

  ids.clear();
  nits = T_flip_edge( pts, triads, slump, numt, 0, ids);
  nit=0;
  
  while(  nits > 0 && nit < 100){

    tf = T_flip_pro_idx( pts, triads, slump, ids);
    nits = (int) ids.size();
    //    cerr << "flipping cycle  " << nit << "   active triangles " << nits << endl;

    //    char tname[128];
    //sprintf(tname,"tris%d.mat",nit);
    //write_Triads(triads, tname);

    nit ++;
    if( tf < 0 ){
      cerr << "cannot triangualte this set " << endl;

      return(-4);
    } 
  }

  if( ids.size() > 0 ){
    // cerr << "degenerate triangulation warning " << endl;
  } 

  return(1);
}




/* 
   flip pairs of triangles that are not valid delaunay triangles
   the Cline-Renka test is used rather than the less stable circum 
   circle center computation test of s-hull.

   or the more expensive determinant test.

 */


int T_flip_pro( std::vector<Shx_int> &pts, std::vector<Triad_int> &triads, std::vector<int> &slump, int numt, int start, std::set<int> &ids){

  int r3,c3;
  int pa,pb,pc, pd, D, L1, L2, L3, L4, T2;

  Triad_int tx, tx2;


  for( int t=start; t<numt; t++){

    Triad_int &tri = triads[t];
    // test all 3 neighbours of tri 


    int flipped = 0;

    if( tri.bc >= 0 ){

      pa = slump[tri.a];
      pb = slump[tri.b];
      pc = slump[tri.c];

      T2 = tri.bc;
      Triad_int &t2 = triads[T2];
      // find relative orientation (shared limb).
      if( t2.ab == t ){
	D = t2.c;
	pd = slump[t2.c];

	if( tri.b == t2.a){
	  L3 = t2.ac;
	  L4 = t2.bc;
	}
	else{
	  L3 = t2.bc;
	  L4 = t2.ac;
	}
      }
      else if(  t2.ac == t ){
	D = t2.b;
	pd = slump[t2.b];
	
	if( tri.b == t2.a){
	  L3 = t2.ab;
	  L4 = t2.bc;
	}
	else{
	  L3 = t2.bc;
	  L4 = t2.ab;
	}
      }
      else if(  t2.bc == t ){
	D = t2.a;
	pd = slump[t2.a];
	
	if( tri.b == t2.b){
	  L3 = t2.ab;
	  L4 = t2.ac;
	}
	else{
	  L3 = t2.ac;
	  L4 = t2.ab;
	}
      }
      else{
	cerr << "triangle flipping error. " << t << endl;
	return(-5);
      }


      if( pd < 0 || pd > 100)
	int dfx = 9;

      r3 = pts[pd].r;
      c3 = pts[pd].c;
      
      int XX = Cline_Renka_test_int( pts[pa].r, pts[pa].c, pts[pb].r, pts[pb].c,  
				  pts[pc].r, pts[pc].c, r3, c3 );
				 
      if( XX < 0 ){ 

	L1 = tri.ab;
	L2 = tri.ac;	
	if( L1 != L3 && L2 != L4 ){  // need this check for stability.

	tx.a = tri.a;
	tx.b = tri.b;
	tx.c = D;
	
	tx.ab = L1;
	tx.ac = T2;
	tx.bc = L3;
	
	
	// triangle 2;
	tx2.a = tri.a;
	tx2.b = tri.c;
	tx2.c = D;
	
	tx2.ab = L2;
	tx2.ac = t;
	tx2.bc = L4;
	

	ids.insert(t);
	ids.insert(T2);
	
	t2 = tx2;
	tri = tx;
	flipped = 1;

	// change knock on triangle labels.
	if( L3 >= 0 ){
	  Triad_int &t3 = triads[L3];
	  if( t3.ab == T2 ) t3.ab = t;
	  else if( t3.bc == T2 ) t3.bc = t;
	  else if( t3.ac == T2 ) t3.ac = t;
	}

	if(L2 >= 0 ){
	  Triad_int &t4 = triads[L2];
	  if( t4.ab == t ) t4.ab = T2;
	  else if( t4.bc == t ) t4.bc = T2;
	  else if( t4.ac == t ) t4.ac = T2;
	}
	}
      }
    }


    if(  flipped == 0 && tri.ab >= 0 ){

      pc = slump[tri.c];
      pb = slump[tri.b];
      pa = slump[tri.a];

      T2 = tri.ab;
      Triad_int &t2 = triads[T2];
      // find relative orientation (shared limb).
      if( t2.ab == t ){
	D = t2.c;
	pd = slump[t2.c];

	if( tri.a == t2.a){
	  L3 = t2.ac;
	  L4 = t2.bc;
	}
	else{
	  L3 = t2.bc;
	  L4 = t2.ac;
	}
      }
      else if(  t2.ac == t ){
	D = t2.b;
	pd = slump[t2.b];
	
	if( tri.a == t2.a){
	  L3 = t2.ab;
	  L4 = t2.bc;
	}
	else{
	  L3 = t2.bc;
	  L4 = t2.ab;
	}
      }
      else if(  t2.bc == t ){
	D = t2.a;
	pd = slump[t2.a];
	
	if( tri.a == t2.b){
	  L3 = t2.ab;
	  L4 = t2.ac;
	}
	else{
	  L3 = t2.ac;
	  L4 = t2.ab;
	}
      }
      else{
	cerr << "triangle flipping error. " << t << endl;
	return(-5);
      }

      r3 = pts[pd].r;
      c3 = pts[pd].c;
      
      int XX = Cline_Renka_test_int( pts[pc].r, pts[pc].c, pts[pb].r, pts[pb].c,  
				  pts[pa].r, pts[pa].c,r3, c3);

      if( XX < 0){ 
	

	L1 = tri.ac;
	L2 = tri.bc;	
	if( L1 != L3 && L2 != L4 ){  // need this check for stability.

	tx.a = tri.c;
	tx.b = tri.a;
	tx.c = D;
	
	tx.ab = L1;
	tx.ac = T2;
	tx.bc = L3;
	
	
	// triangle 2;
	tx2.a = tri.c;
	tx2.b = tri.b;
	tx2.c = D;
	
	tx2.ab = L2;
	tx2.ac = t;
	tx2.bc = L4;
	

	ids.insert(t);
	ids.insert(T2);
	
	t2 = tx2;
	tri = tx;
	flipped = 1;

	// change knock on triangle labels.
	if( L3 >= 0 ){
	  Triad_int &t3 = triads[L3];
	  if( t3.ab == T2 ) t3.ab = t;
	  else if( t3.bc == T2 ) t3.bc = t;
	  else if( t3.ac == T2 ) t3.ac = t;
	}

	if(L2 >= 0 ){
	  Triad_int &t4 = triads[L2];
	  if( t4.ab == t ) t4.ab = T2;
	  else if( t4.bc == t ) t4.bc = T2;
	  else if( t4.ac == t ) t4.ac = T2;
	}

	}

      }
    }


    if( flipped == 0 && tri.ac >= 0 ){

      pc = slump[tri.c];
      pb = slump[tri.b];
      pa = slump[tri.a];

      T2 = tri.ac;
      Triad_int &t2 = triads[T2];
      // find relative orientation (shared limb).
      if( t2.ab == t ){
	D = t2.c;
	pd = slump[t2.c];

	if( tri.a == t2.a){
	  L3 = t2.ac;
	  L4 = t2.bc;
	}
	else{
	  L3 = t2.bc;
	  L4 = t2.ac;
	}
      }
      else if(  t2.ac == t ){
	D = t2.b;
	pd = slump[t2.b];
	
	if( tri.a == t2.a){
	  L3 = t2.ab;
	  L4 = t2.bc;
	}
	else{
	  L3 = t2.bc;
	  L4 = t2.ab;
	}
      }
      else if(  t2.bc == t ){
	D = t2.a;
	pd = slump[t2.a];
	
	if( tri.a == t2.b){
	  L3 = t2.ab;
	  L4 = t2.ac;
	}
	else{
	  L3 = t2.ac;
	  L4 = t2.ab;
	}
      }
      else{
	cerr << "triangle flipping error. " << t << endl;
	return(-5);
      }

      r3 = pts[pd].r;
      c3 = pts[pd].c;
      
      int XX = Cline_Renka_test_int( pts[pb].r, pts[pb].c, pts[pa].r, pts[pa].c,  
				  pts[pc].r, pts[pc].c,r3, c3);

      if( XX < 0 ){ 

	L1 = tri.ab;   // .ac shared limb
	L2 = tri.bc;	
	if( L1 != L3 && L2 != L4 ){  // need this check for stability.

	tx.a = tri.b;
	tx.b = tri.a;
	tx.c = D;
	
	tx.ab = L1;
	tx.ac = T2;
	tx.bc = L3;
	
	
	// triangle 2;
	tx2.a = tri.b;
	tx2.b = tri.c;
	tx2.c = D;
	
	tx2.ab = L2;
	tx2.ac = t;
	tx2.bc = L4;
       
	ids.insert(t);
	ids.insert(T2);
	
	t2 = tx2;
	tri = tx;

	// change knock on triangle labels.
	if( L3 >= 0 ){
	  Triad_int &t3 = triads[L3];
	  if( t3.ab == T2 ) t3.ab = t;
	  else if( t3.bc == T2 ) t3.bc = t;
	  else if( t3.ac == T2 ) t3.ac = t;
	}

	if(L2 >= 0 ){
	  Triad_int &t4 = triads[L2];
	  if( t4.ab == t ) t4.ab = T2;
	  else if( t4.bc == t ) t4.bc = T2;
	  else if( t4.ac == t ) t4.ac = T2;
	}

	}
      }
    }

   
  }


  return(1);
}
 
/* minimum angle cnatraint for circum circle test.
   due to Cline & Renka

   A   --    B
 
   |    /    |

   C   --    D

   
 */

int Cline_Renka_test_int(int &Ax, int &Ay,
		      int &Bx, int &By, 
		      int &Cx, int &Cy,
		      int &Dx, int &Dy)
{

  int v1x = Bx-Ax, v1y = By-Ay,    v2x = Cx-Ax, v2y = Cy-Ay,
    v3x = Bx-Dx, v3y = By-Dy,    v4x = Cx-Dx, v4y = Cy-Dy; 
  int cosA = v1x*v2x + v1y*v2y;
  int cosD = v3x*v4x + v3y*v4y;

  if( cosA < 0 && cosD < 0 ) // two obtuse angles 
    return(-1);

  int ADX = Ax-Dx, ADy = Ay-Dy;


  if( cosA > 0 && cosD > 0 )  // two acute angles
    return(1);


  int sinA = abs(v1x*v2y - v1y*v2x);
  int sinD = abs(v3x*v4y - v3y*v4x);

  if( cosA*sinD + sinA*cosD < 0 )
    return(-1);

  return(1);

}
  


int Cline_Renka_test_double(int &Ax, int &Ay,
		      int &Bx, int &By, 
		      int &Cx, int &Cy,
		      int &Dx, int &Dy)
{

  double v1x = Bx-Ax, v1y = By-Ay,    v2x = Cx-Ax, v2y = Cy-Ay,
    v3x = Bx-Dx, v3y = By-Dy,    v4x = Cx-Dx, v4y = Cy-Dy; 
  double cosA = v1x*v2x + v1y*v2y;
  double cosD = v3x*v4x + v3y*v4y;

  if( cosA < 0 && cosD < 0 ) // two obtuse angles 
    return(-1);

  double ADX = Ax-Dx, ADy = Ay-Dy;


  if( cosA > 0 && cosD > 0 )  // two acute angles
    return(1);


  double sinA = (v1x*v2y - v1y*v2x);
  if( sinA < 0 ) sinA *=-1; 
  double sinD = (v3x*v4y - v3y*v4x);
  if( sinD < 0 ) sinD *=-1; 


  if( cosA*sinD + sinA*cosD < 0 )
    return(-1);

  return(1);

}
  


// same again but with set of triangle ids to be iterated over.


int T_flip_pro_idx( std::vector<Shx_int> &pts, std::vector<Triad_int> &triads, std::vector<int> &slump, std::set<int> &ids){

  int  r3,c3;
  int pa,pb,pc, pd,  D, L1, L2, L3, L4, T2;

  Triad_int tx, tx2;
  std::set<int> ids2;
  ids2.clear();

  std::set<int> :: const_iterator x=ids.begin();
  while(x != ids.end() ){
    int t = *x;
    x++;
    

    Triad_int &tri = triads[t];
    // test all 3 neighbours of tri 
    int flipped = 0;

   

    if( tri.bc >= 0 ){

      pa = slump[tri.a];
      pb = slump[tri.b];
      pc = slump[tri.c];

      T2 = tri.bc;
      Triad_int &t2 = triads[T2];
      // find relative orientation (shared limb).
      if( t2.ab == t ){
	D = t2.c;
	pd = slump[t2.c];

	if( tri.b == t2.a){
	  L3 = t2.ac;
	  L4 = t2.bc;
	}
	else{
	  L3 = t2.bc;
	  L4 = t2.ac;
	}
      }
      else if(  t2.ac == t ){
	D = t2.b;
	pd = slump[t2.b];
	
	if( tri.b == t2.a){
	  L3 = t2.ab;
	  L4 = t2.bc;
	}
	else{
	  L3 = t2.bc;
	  L4 = t2.ab;
	}
      }
      else if(  t2.bc == t ){
	D = t2.a;
	pd = slump[t2.a];
	
	if( tri.b == t2.b){
	  L3 = t2.ab;
	  L4 = t2.ac;
	}
	else{
	  L3 = t2.ac;
	  L4 = t2.ab;
	}
      }
      else{
	cerr << "triangle flipping error. " << t << "  T2: " <<  T2<<  endl;
	return(-6);
      }

      r3 = pts[pd].r;
      c3 = pts[pd].c;    

      int XX = Cline_Renka_test_int( pts[pa].r, pts[pa].c, pts[pb].r, pts[pb].c,  
				  pts[pc].r, pts[pc].c,r3, c3);

      if( XX < 0 ){ 
	L1 = tri.ab;
	L2 = tri.ac;	

	if( L1 != L3 && L2 != L4 ){  // need this check for stability.
      

	tx.a = tri.a;
	tx.b = tri.b;
	tx.c = D;
	
	tx.ab = L1;
	tx.ac = T2;
	tx.bc = L3;
	
	
	// triangle 2;
	tx2.a = tri.a;
	tx2.b = tri.c;
	tx2.c = D;
	
	tx2.ab = L2;
	tx2.ac = t;
	tx2.bc = L4;
		
	ids2.insert(t);
	ids2.insert(T2);
	
	t2 = tx2;
	tri = tx;
	flipped = 1;

	// change knock on triangle labels.
	if( L3 >= 0 ){
	  Triad_int &t3 = triads[L3];
	  if( t3.ab == T2 ) t3.ab = t;
	  else if( t3.bc == T2 ) t3.bc = t;
	  else if( t3.ac == T2 ) t3.ac = t;
	}

	if(L2 >= 0 ){
	  Triad_int &t4 = triads[L2];
	  if( t4.ab == t ) t4.ab = T2;
	  else if( t4.bc == t ) t4.bc = T2;
	  else if( t4.ac == t ) t4.ac = T2;
	}

	}
      }
    }


    if( flipped == 0 && tri.ab >= 0 ){

      pc = slump[tri.c];
      pb = slump[tri.b];
      pa = slump[tri.a];

      T2 = tri.ab;
      Triad_int &t2 = triads[T2];
      // find relative orientation (shared limb).
      if( t2.ab == t ){
	D = t2.c;
	pd = slump[t2.c];

	if( tri.a == t2.a){
	  L3 = t2.ac;
	  L4 = t2.bc;
	}
	else{
	  L3 = t2.bc;
	  L4 = t2.ac;
	}
      }
      else if(  t2.ac == t ){
	D = t2.b;
	pd = slump[t2.b];
	
	if( tri.a == t2.a){
	  L3 = t2.ab;
	  L4 = t2.bc;
	}
	else{
	  L3 = t2.bc;
	  L4 = t2.ab;
	}
      }
      else if(  t2.bc == t ){
	D = t2.a;
	pd = slump[t2.a];
	
	if( tri.a == t2.b){
	  L3 = t2.ab;
	  L4 = t2.ac;
	}
	else{
	  L3 = t2.ac;
	  L4 = t2.ab;
	}
      }
      else{
	cerr << "triangle flipping error. " << t <<  endl;
	return(-6);
      }

      r3 = pts[pd].r;
      c3 = pts[pd].c;   

      int XX = Cline_Renka_test_int( pts[pc].r, pts[pc].c, pts[pb].r, pts[pb].c,  
				  pts[pa].r, pts[pa].c,r3, c3);

      if( XX < 0 ){ 
	L1 = tri.ac;
	L2 = tri.bc;	
      	if( L1 != L3 && L2 != L4 ){  // need this check for stability.
	
	tx.a = tri.c;
	tx.b = tri.a;
	tx.c = D;
	
	tx.ab = L1;
	tx.ac = T2;
	tx.bc = L3;
	
	
	// triangle 2;
	tx2.a = tri.c;
	tx2.b = tri.b;
	tx2.c = D;
	
	tx2.ab = L2;
	tx2.ac = t;
	tx2.bc = L4;
	
	
	ids2.insert(t);
	ids2.insert(T2);
	
	t2 = tx2;
	tri = tx;
	flipped = 1;

	// change knock on triangle labels.
	if( L3 >= 0 ){
	  Triad_int &t3 = triads[L3];
	  if( t3.ab == T2 ) t3.ab = t;
	  else if( t3.bc == T2 ) t3.bc = t;
	  else if( t3.ac == T2 ) t3.ac = t;
	}

	if(L2 >= 0 ){
	  Triad_int &t4 = triads[L2];
	  if( t4.ab == t ) t4.ab = T2;
	  else if( t4.bc == t ) t4.bc = T2;
	  else if( t4.ac == t ) t4.ac = T2;
	}

	}
      }
    }


    if( flipped == 0 && tri.ac >= 0 ){

      pc = slump[tri.c];
      pb = slump[tri.b];
      pa = slump[tri.a];

      T2 = tri.ac;
      Triad_int &t2 = triads[T2];
      // find relative orientation (shared limb).
      if( t2.ab == t ){
	D = t2.c;
	pd = slump[t2.c];

	if( tri.a == t2.a){
	  L3 = t2.ac;
	  L4 = t2.bc;
	}
	else{
	  L3 = t2.bc;
	  L4 = t2.ac;
	}
      }
      else if(  t2.ac == t ){
	D = t2.b;
	pd = slump[t2.b];
	
	if( tri.a == t2.a){
	  L3 = t2.ab;
	  L4 = t2.bc;
	}
	else{
	  L3 = t2.bc;
	  L4 = t2.ab;
	}
      }
      else if(  t2.bc == t ){
	D = t2.a;
	pd = slump[t2.a];
	
	if( tri.a == t2.b){
	  L3 = t2.ab;
	  L4 = t2.ac;
	}
	else{
	  L3 = t2.ac;
	  L4 = t2.ab;
	}
      }
      else{
	cerr << "triangle flipping error. " << t << endl;
	return(-6);
      }

      r3 = pts[pd].r;
      c3 = pts[pd].c;   

      int XX = Cline_Renka_test_int( pts[pb].r, pts[pb].c, pts[pc].r, pts[pc].c,  
				 pts[pa].r, pts[pa].c,r3, c3);

      if( XX < 0 ){ 
	L1 = tri.ab;   // .ac shared limb
	L2 = tri.bc;	
      	if( L1 != L3 && L2 != L4 ){  // need this check for stability.


	tx.a = tri.b;
	tx.b = tri.a;
	tx.c = D;
	
	tx.ab = L1;
	tx.ac = T2;
	tx.bc = L3;
	
	
	// triangle 2;
	tx2.a = tri.b;
	tx2.b = tri.c;
	tx2.c = D;


	
	tx2.ab = L2;
	tx2.ac = t;
	tx2.bc = L4;


	ids2.insert(t);
	ids2.insert(T2);
	
	t2 = tx2;
	tri = tx;
	
	// change knock on triangle labels.
	if( L3 >= 0 ){
	  Triad_int &t3 = triads[L3];
	  if( t3.ab == T2 ) t3.ab = t;
	  else if( t3.bc == T2 ) t3.bc = t;
	  else if( t3.ac == T2 ) t3.ac = t;
	}
	
	if(L2 >= 0 ){
	  Triad_int &t4 = triads[L2];
	  if( t4.ab == t ) t4.ab = T2;
	  else if( t4.bc == t ) t4.bc = T2;
	  else if( t4.ac == t ) t4.ac = T2;
	}


	}
      }
    }


  }

  ids.clear();
  ids.insert(ids2.begin(), ids2.end());

  return(1);
}



int T_flip_edge( std::vector<Shx_int> &pts, std::vector<Triad_int> &triads, std::vector<int> &slump, int numt, int start, std::set<int> &ids){

  int r3,c3;
  int pa,pb,pc, pd, D, L1, L2, L3, L4, T2;

  Triad_int tx, tx2;


  for( int t=start; t<numt; t++){

    Triad_int &tri = triads[t];
    // test all 3 neighbours of tri 


    //  if( t == 90 )
    // int guvk = 9;


    int flipped = 0;

    if( tri.bc >= 0 && (tri.ac < 0 || tri.ab < 0) ){

      pa = slump[tri.a];
      pb = slump[tri.b];
      pc = slump[tri.c];

      T2 = tri.bc;
      Triad_int &t2 = triads[T2];
      // find relative orientation (shared limb).
      if( t2.ab == t ){
	D = t2.c;
	pd = slump[t2.c];

	if( tri.b == t2.a){
	  L3 = t2.ac;
	  L4 = t2.bc;
	}
	else{
	  L3 = t2.bc;
	  L4 = t2.ac;
	}
      }
      else if(  t2.ac == t ){
	D = t2.b;
	pd = slump[t2.b];
	
	if( tri.b == t2.a){
	  L3 = t2.ab;
	  L4 = t2.bc;
	}
	else{
	  L3 = t2.bc;
	  L4 = t2.ab;
	}
      }
      else if(  t2.bc == t ){
	D = t2.a;
	pd = slump[t2.a];
	
	if( tri.b == t2.b){
	  L3 = t2.ab;
	  L4 = t2.ac;
	}
	else{
	  L3 = t2.ac;
	  L4 = t2.ab;
	}
      }
      else{
	cerr << "triangle flipping error. " << t << endl;
	return(-5);
      }



      r3 = pts[pd].r;
      c3 = pts[pd].c;
      
      int XX = Cline_Renka_test_int( pts[pa].r, pts[pa].c, pts[pb].r, pts[pb].c,  
				  pts[pc].r, pts[pc].c, r3, c3 );
				 
      if( XX < 0 ){ 

	L1 = tri.ab;
	L2 = tri.ac;	
	//	if( L1 != L3 && L2 != L4 ){  // need this check for stability.

	tx.a = tri.a;
	tx.b = tri.b;
	tx.c = D;
	
	tx.ab = L1;
	tx.ac = T2;
	tx.bc = L3;
	
	
	// triangle 2;
	tx2.a = tri.a;
	tx2.b = tri.c;
	tx2.c = D;
	
	tx2.ab = L2;
	tx2.ac = t;
	tx2.bc = L4;
	

	ids.insert(t);
	ids.insert(T2);
	
	t2 = tx2;
	tri = tx;
	flipped = 1;

	// change knock on triangle labels.
	if( L3 >= 0 ){
	  Triad_int &t3 = triads[L3];
	  if( t3.ab == T2 ) t3.ab = t;
	  else if( t3.bc == T2 ) t3.bc = t;
	  else if( t3.ac == T2 ) t3.ac = t;
	}

	if(L2 >= 0 ){
	  Triad_int &t4 = triads[L2];
	  if( t4.ab == t ) t4.ab = T2;
	  else if( t4.bc == t ) t4.bc = T2;
	  else if( t4.ac == t ) t4.ac = T2;
	}
	//	}
      }
    }


    if(  flipped == 0 && tri.ab >= 0 && (tri.ac < 0 || tri.bc < 0)){

      pc = slump[tri.c];
      pb = slump[tri.b];
      pa = slump[tri.a];

      T2 = tri.ab;
      Triad_int &t2 = triads[T2];
      // find relative orientation (shared limb).
      if( t2.ab == t ){
	D = t2.c;
	pd = slump[t2.c];

	if( tri.a == t2.a){
	  L3 = t2.ac;
	  L4 = t2.bc;
	}
	else{
	  L3 = t2.bc;
	  L4 = t2.ac;
	}
      }
      else if(  t2.ac == t ){
	D = t2.b;
	pd = slump[t2.b];
	
	if( tri.a == t2.a){
	  L3 = t2.ab;
	  L4 = t2.bc;
	}
	else{
	  L3 = t2.bc;
	  L4 = t2.ab;
	}
      }
      else if(  t2.bc == t ){
	D = t2.a;
	pd = slump[t2.a];
	
	if( tri.a == t2.b){
	  L3 = t2.ab;
	  L4 = t2.ac;
	}
	else{
	  L3 = t2.ac;
	  L4 = t2.ab;
	}
      }
      else{
	cerr << "triangle flipping error. " << t << endl;
	return(-5);
      }

      r3 = pts[pd].r;
      c3 = pts[pd].c;
      
      int XX = Cline_Renka_test_int( pts[pc].r, pts[pc].c, pts[pb].r, pts[pb].c,  
				  pts[pa].r, pts[pa].c,r3, c3);

      if( XX < 0){ 
	

	L1 = tri.ac;
	L2 = tri.bc;	
	//	if( L1 != L3 && L2 != L4 ){  // need this check for stability.

	tx.a = tri.c;
	tx.b = tri.a;
	tx.c = D;
	
	tx.ab = L1;
	tx.ac = T2;
	tx.bc = L3;
	
	
	// triangle 2;
	tx2.a = tri.c;
	tx2.b = tri.b;
	tx2.c = D;
	
	tx2.ab = L2;
	tx2.ac = t;
	tx2.bc = L4;
	

	ids.insert(t);
	ids.insert(T2);
	
	t2 = tx2;
	tri = tx;
	flipped = 1;

	// change knock on triangle labels.
	if( L3 >= 0 ){
	  Triad_int &t3 = triads[L3];
	  if( t3.ab == T2 ) t3.ab = t;
	  else if( t3.bc == T2 ) t3.bc = t;
	  else if( t3.ac == T2 ) t3.ac = t;
	}

	if(L2 >= 0 ){
	  Triad_int &t4 = triads[L2];
	  if( t4.ab == t ) t4.ab = T2;
	  else if( t4.bc == t ) t4.bc = T2;
	  else if( t4.ac == t ) t4.ac = T2;
	}

	//	}

      }
    }


    if( flipped == 0 && tri.ac >= 0 && (tri.bc < 0 || tri.ab < 0) ){

      pc = slump[tri.c];
      pb = slump[tri.b];
      pa = slump[tri.a];

      T2 = tri.ac;
      Triad_int &t2 = triads[T2];
      // find relative orientation (shared limb).
      if( t2.ab == t ){
	D = t2.c;
	pd = slump[t2.c];

	if( tri.a == t2.a){
	  L3 = t2.ac;
	  L4 = t2.bc;
	}
	else{
	  L3 = t2.bc;
	  L4 = t2.ac;
	}
      }
      else if(  t2.ac == t ){
	D = t2.b;
	pd = slump[t2.b];
	
	if( tri.a == t2.a){
	  L3 = t2.ab;
	  L4 = t2.bc;
	}
	else{
	  L3 = t2.bc;
	  L4 = t2.ab;
	}
      }
      else if(  t2.bc == t ){
	D = t2.a;
	pd = slump[t2.a];
	
	if( tri.a == t2.b){
	  L3 = t2.ab;
	  L4 = t2.ac;
	}
	else{
	  L3 = t2.ac;
	  L4 = t2.ab;
	}
      }
      else{
	cerr << "triangle flipping error. " << t << endl;
	return(-5);
      }

      r3 = pts[pd].r;
      c3 = pts[pd].c;
      
      int XX = Cline_Renka_test_int( pts[pb].r, pts[pb].c, pts[pa].r, pts[pa].c,  
				  pts[pc].r, pts[pc].c,r3, c3);

      if( XX < 0 ){ 

	L1 = tri.ab;   // .ac shared limb
	L2 = tri.bc;	
	//	if( L1 != L3 && L2 != L4 ){  // need this check for stability.

	tx.a = tri.b;
	tx.b = tri.a;
	tx.c = D;
	
	tx.ab = L1;
	tx.ac = T2;
	tx.bc = L3;
	
	
	// triangle 2;
	tx2.a = tri.b;
	tx2.b = tri.c;
	tx2.c = D;
	
	tx2.ab = L2;
	tx2.ac = t;
	tx2.bc = L4;
       
	ids.insert(t);
	ids.insert(T2);
	
	t2 = tx2;
	tri = tx;

	// change knock on triangle labels.
	if( L3 >= 0 ){
	  Triad_int &t3 = triads[L3];
	  if( t3.ab == T2 ) t3.ab = t;
	  else if( t3.bc == T2 ) t3.bc = t;
	  else if( t3.ac == T2 ) t3.ac = t;
	}

	if(L2 >= 0 ){
	  Triad_int &t4 = triads[L2];
	  if( t4.ab == t ) t4.ab = T2;
	  else if( t4.bc == t ) t4.bc = T2;
	  else if( t4.ac == t ) t4.ac = T2;
	}

	//	}
      }
    }

   
  }


  return(1);
}
 
