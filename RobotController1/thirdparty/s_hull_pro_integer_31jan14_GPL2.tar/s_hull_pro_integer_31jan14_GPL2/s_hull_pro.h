#ifndef _structures_h
#define _structures_h




// for FILE
//#include <stdio.h>
//#include <iostream>
#include <stdlib.h>
#include <vector>
#include <set>



/* 
   for use in s_hull_pro_integer.cpp

   S-hull-pro_Integer, Copyright (c) 2012
   Dr David Sinclair
   email david@s-hull.org

   this code is released under GPL2, 
   a copy ofthe license can be found at
   http://www.gnu.org/licenses/gpl-2.0.html

   you can purchase a un-restricted licnese from 
   http://www.s-hull.org 
   for the price of one beer!
   

*/



struct Triad_int
{
  int a,b, c;
  int ab, bc, ac;  // adjacent edges index to neighbouring triangle.
  Triad_int() {};
  Triad_int(int x, int y) : a(x), b(y),c(0), ab(-1), bc(-1), ac(-1) {};
  Triad_int(int x, int y, int z) : a(x), b(y), c(z),  ab(-1), bc(-1), ac(-1){};
  Triad_int(const Triad_int &p) : a(p.a), b(p.b), c(p.c), ab(p.ab), bc(p.bc), ac(p.ac) {};

  Triad_int &operator=(const Triad_int &p)
  {
    a = p.a;
    b = p.b;
    c = p.c;

    ab = p.ab;
    bc = p.bc;
    ac = p.ac;


    return *this;
  };
  // void prnt(){
  //cerr << a << " " << b << " " << c << "   " << ab << " " << ac << " " << bc << endl;
  //};
};



/* point structure for s_hull only.
   has to keep track of triangle ids as hull evolves.


*/


struct Shx_int
{
  int id, trid;
  int r,c, tr,tc ;

  Shx_int() {};
  Shx_int(int a, int b) : r(a), c(b),  tr(0), tc(0), id(-1) {}; 
  //Shx_int(int a, int b, float x) : r(a), c(b), id(-1), tr(0), tc(0) {};
  Shx_int(const Shx_int &p) : id(p.id), trid(p.trid), r(p.r), c(p.c), tr(p.tr), tc(p.tc) {};

  Shx_int &operator=(const Shx_int &p)
  {
    id = p.id;
    trid = p.trid;
    r = p.r;
    c = p.c;
    tr = p.tr;
    tc = p.tc;
    return *this;
  };

};


// sort into ascending order (for use in corner responce ranking).
inline bool operator<(const Shx_int &a, const Shx_int &b) 
{ 
  if( a.r == b.r)
    return a.c < b.c;
  return a.r <  b.r;
};





// from s_hull.C


int T_flip_pro( std::vector<Shx_int> &pts, 
		std::vector<Triad_int> &triads, 
		std::vector<int> &slump, 
		int numt, int start, std::set<int> &ids);

int T_flip_pro_idx( std::vector<Shx_int> &pts, 
		    std::vector<Triad_int> &triads, 
		    std::vector<int> &slump, 
		    std::set<int> &ids);

int Cline_Renka_test_int(int &Ax, int &Ay, 
			 int &Bx, int &By, 
			 int &Cx, int &Cy, 
			 int &Dx, int &Dy);
int Cline_Renka_test_double(int &Ax, int &Ay,
			    int &Bx, int &By, 
			    int &Cx, int &Cy,
			    int &Dx, int &Dy);


int init_hull_int( std::vector<Shx_int> &pts, 
		   std::vector<Shx_int> &hull, 
		   std::vector<Triad_int> &triads);

int s_hull_pro_integer( std::vector<Shx_int> &pts, std::vector<Triad_int> &triads);

int  read_Shx    (std::vector<Shx_int>  &pts, char * fname);
void write_Shx   (std::vector<Shx_int>  &pts, char * fname);
void write_Triads(std::vector<Triad_int> &ts, char * fname);

int T_flip_edge( std::vector<Shx_int> &pts, std::vector<Triad_int> &triads, std::vector<int> &slump, int numt, int start, std::set<int> &ids);

#endif
